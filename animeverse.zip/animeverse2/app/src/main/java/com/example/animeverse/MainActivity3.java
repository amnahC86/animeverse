package com.example.animeverse;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        ArrayList<Animeverse> myAnime = new ArrayList<>();
        Animeverse a1 = new Animeverse("steinsgate" , "mistary" , 14 , R.drawable.steinsgate);
        myAnime.add(a1);
        Animeverse a2 = new Animeverse("myheroacademy" , "adventure" , 12 , R.drawable.mha);
        myAnime.add(a2);
        Animeverse a3 = new Animeverse("yourlieinapril" , "sad" , 13 , R.drawable.yourlieinapril);
        myAnime.add(a3);
        Animeverse a4 = new Animeverse("haikyuu" , "wholesome" , 12 , R.drawable.haikyuu);
        myAnime.add(a4);
        Animeverse a5 = new Animeverse("naruto" , "adventure" , 11 , R.drawable.naruto);
        myAnime.add(a5);
        RecyclerView rv = findViewById(R.id.rv);
        rv.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);
        adapter ad = new adapter(myAnime,this);
        rv.setAdapter(ad);
    }
}