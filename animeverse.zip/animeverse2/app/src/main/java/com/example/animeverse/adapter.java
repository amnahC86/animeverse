package com.example.animeverse;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.view.menu.MenuView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adapter extends RecyclerView.Adapter {

    ArrayList<Animeverse>listA;
    Context context;

    public adapter(ArrayList<Animeverse> listA, Context context) {
        this.listA = listA;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).img.setImageResource(listA.get(position).getImage());
        ((ViewHolder) holder).ganra.setText(listA.get(position).getGanra() + "");
        ((ViewHolder) holder).name.setText(listA.get(position).getName());
        ((ViewHolder) holder).age.setText(listA.get(position).getAge() + "");
    }



    @Override
    public int getItemCount() {
        return listA.size();

    }
    public static class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView img ;
        public TextView age ;
        public TextView name ;
        public TextView ganra ;
        public View view ;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
            img = itemView.findViewById(R.id.image1);
            age = itemView.findViewById(R.id.age1);
            name = itemView.findViewById(R.id.name1);
            ganra = itemView.findViewById(R.id.genara1);
        }
    }
}
