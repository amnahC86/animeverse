package com.example.animeverse;

import java.io.Serializable;

public class Animeverse implements Serializable {
   private String name;
   private String ganra;
    private int age;

    public Animeverse(String name, String ganra, int age) {
        this.name = name;
        this.ganra = ganra;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGanra() {
        return ganra;
    }

    public void setGanra(String ganra) {
        this.ganra = ganra;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
